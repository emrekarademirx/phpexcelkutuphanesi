<?php

	set_include_path(get_include_path() . PATH_SEPARATOR . 'Classes/');
	include 'PHPExcel/IOFactory.php';
	$Excel = new PHPExcel();

	$Excel->getProperties()->setCreator("Tam Liste")
	setLastModifiedBy("Tam Liste")
	->setTitle("Tam Liste")
	->setSubject("Tam Liste")
	->setDescription("Tam Liste")
	->setKeywords("Tam Liste")
	->setCategory("Tam Liste");
	$Excel->getActiveSheet()->setTitle('Sayfa1');

	$Excel->getActiveSheet()->setCellValue('A1', 'Adı');
	$Excel->getActiveSheet()->setCellValue('B1', 'Soyadı');
	$Excel->getActiveSheet()->setCellValue('C1', 'Telefon');
	$Excel->getActiveSheet()->setCellValue('D1', 'ePosta');
	$tur = 2;

	/**
	* Eğer bir dizininiz varsa foreach kullanabilirsiniz.
	*/
	foreach($kullanicilar as $kullanici){
		$Excel->getActiveSheet()->setCellValue("A$tur", "Emre");
		$Excel->getActiveSheet()->setCellValue("B$tur", "Karademir");
		$Excel->getActiveSheet()->setCellValue("C$tur", "05551234567");
		$Excel->getActiveSheet()->setCellValue("D$tur", "info@emrekarademir.com";
		$tur++;
	}
		$Kaydet = PHPExcel_IOFactory::createWriter($Excel, 'Excel5');
		$Kaydet->save("excel.xls");


?>